### R code from vignette source 'dice.Rnw'

###################################################
### code chunk number 1: Make_data_source_table
###################################################
library(DICE)
library(xtable)
myDB = OpenCon()
data_sources = dbReadTable(myDB, "data_sources")
invisible(dbDisconnect(myDB))
# reduce to 4 columns
table_df = data_sources[, c("source_key", "source_abbv", "disease", "source_desc")]
# reduce description to 20 characters
table_df$source_desc = substr(table_df$source_desc, start=1, stop=45)
# generate table
print(xtable(table_df, caption=paste0("Complete list of DICE database data-sources as of ", Sys.Date(), "."), label="tab:sources", align="r|r|l|l|l|"), include.rownames=FALSE, include.colnames=TRUE, caption.placement='top')


